const pillars = [
  {
    number: "01",
    title: "The child's safe place",
    description:
      "A private, pressure-free sanctuary where children can explore thoughts, articulate feelings, and express what they're experiencing without fear of judgment.",
    label: "SANCTUARY",
    accent: "warm",
  },
  {
    number: "02",
    title: "The child's agency",
    description:
      "Empowering children to choose when, how, and with whom they share their story, restoring control and autonomy at their own pace.",
    label: "AUTONOMY",
    accent: "sage",
  },
  {
    number: "03",
    title: "The child/adult connection",
    description:
      "Gently scaffolding the bridge between the child's unspoken world and the trusted adult's compassionate, prepared response.",
    label: "BRIDGE",
    accent: "warm",
  },
]

const pathways = [
  {
    title: "Parents & Caregivers",
    description:
      "Learn about our upcoming family pilot and quiet conversation tools designed for household safety.",
  },
  {
    title: "Clinicians & Researchers",
    description:
      "Learn about the Clinical Advisory roles yuli is seeking, the clinical research yuli is grounded on, or how you can get in touch if you want to learn more.",
  },
  {
    title: "Channels",
    description:
      "Are you a school, youth organization, or another business interested in partnering with yuli? Let's get in touch.",
  },
]

function Brand({ footer = false }: { footer?: boolean }) {
  return (
    <div className={`brand ${footer ? "brand--footer" : ""}`}>
      <span className="brand__name">yuli</span>
      {footer && <span className="brand__dot">•</span>}
      <span className="brand__tagline">where little voices find the light</span>
    </div>
  )
}

function FireflyOrbit() {
  return (
    <div
      className="orbit"
      aria-label="A safe, comforting, trauma-informed space"
    >
      <div className="orbit__ambient" />
      <div className="orbit__ring orbit__ring--outer" />
      <div className="orbit__ring orbit__ring--large" />
      <div className="orbit__ring orbit__ring--middle">
        <i />
        <i />
      </div>
      <div className="orbit__ring orbit__ring--inner" />
      <span className="orbit__label orbit__label--one">age adaptive</span>
      <span className="orbit__label orbit__label--three">trauma-informed</span>
      <span className="orbit__label orbit__label--four">privacy</span>
      <span className="orbit__label orbit__label--five">connection</span>
      <span className="orbit__label orbit__label--six">child-centered</span>
      <div className="firefly">
        <div className="firefly__glow" />
        <div className="firefly__body">
          <i className="firefly__wing firefly__wing--left" />
          <i className="firefly__wing firefly__wing--right" />
          <i className="firefly__head" />
          <i className="firefly__lantern">
            <b />
          </i>
        </div>
        <div className="firefly__legend">
          <i />
          <span />
          SAFE HOLDING SPACE
          <span />
          <i />
        </div>
      </div>
    </div>
  )
}

function Header() {
  return (
    <header className="site-header">
      <div className="shell site-header__inner">
        <a href="#" aria-label="yuli home">
          <Brand />
        </a>
        <nav className="nav" aria-label="Main navigation">
          <a className="nav__active" href="#why">
            Why yuli
          </a>
          <a href="#how">How it works</a>
          <a href="#evidence">Evidence</a>
          <a href="#clinicians">For clinicians</a>
          <a href="#investors">For investors</a>
          <a href="#about">About</a>
        </nav>
        <a className="button button--header" href="#connect">
          Connect with yuli
        </a>
      </div>
    </header>
  )
}

export default function App() {
  return (
    <div className="page">
      <Header />
      <main>
        <section className="hero" id="why">
          <div className="shell hero__grid">
            <div className="hero__copy">
              <div className="eyebrow">
                <i />
                SILENCE ISN&apos;T A CHOICE. IT&apos;S A DESIGN FAILURE.
              </div>
              <h1>
                What if the problem in child safety isn&apos;t that children
                don&apos;t want to tell someone?
              </h1>
              <p className="hero__prompt">
                What if it&apos;s that we&apos;ve never given them a way to
                start?
              </p>
              <div className="quote">
                yuli is a child-centered communication platform designed to help
                children begin a difficult conversation with a trusted adult,
                and help that adult respond with care.
              </div>
              <div className="hero__actions">
                <a className="button button--primary" href="#how">
                  Explore how yuli works
                  <img src="/assets/558b2.svg" alt="" />
                </a>
                <a className="button button--secondary" href="#evidence">
                  Read the research
                </a>
              </div>
            </div>
            <FireflyOrbit />
          </div>
        </section>

        <section className="pillars" id="evidence">
          <div className="shell">
            <div className="section-heading">
              <div className="section-kicker">
                <span>
                  <i />
                  THE MISSING BRIDGE
                </span>
                <b />
              </div>
              <h2>
                yuli doesn&apos;t replace the conversation. It
                <br />
                helps your child start it.
              </h2>
              <p>THREE GUIDING PILLARS</p>
            </div>
            <div className="pillar-grid">
              {pillars.map((pillar) => (
                <a
                  className={`pillar-card pillar-card--${pillar.accent}`}
                  href="#connect"
                  key={pillar.number}
                >
                  <div className="pillar-card__wash" />
                  <div className="pillar-card__top">
                    <span>PILLAR {pillar.number}</span>
                    <i />
                  </div>
                  <h3>{pillar.title}</h3>
                  <p>{pillar.description}</p>
                  <div className="pillar-card__foot">
                    <span>{pillar.label}</span>
                    <span>→</span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>

        <section className="pathways" id="how">
          <div className="shell">
            <div className="pathways__heading">
              <p>ENGAGEMENT PATHWAYS</p>
              <h2>Find your way in</h2>
            </div>
            <div className="pathway-grid">
              {pathways.map((pathway) => (
                <a className="pathway-card" href="#connect" key={pathway.title}>
                  <span className="pathway-card__meta">SAFE HOLDING SPACE</span>
                  <h3>{pathway.title}</h3>
                  <p>{pathway.description}</p>
                  <span className="pathway-card__arrow">
                    <img src="/assets/2ff22.svg" alt="" />
                  </span>
                </a>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer id="connect">
        <div className="shell footer__inner">
          <Brand footer />
          <div className="footer__legal">
            <span>CLINICAL PROTOCOL v2.4</span>
            <span>© 20262026202620262026 yuli. All rights reserved.</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
